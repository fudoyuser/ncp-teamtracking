// Nút "Gửi sang PCCV" (bookmarklet) – chạy trên trang Facebook mà CHÍNH NGƯỜI DÙNG đang mở.
// Việc nó làm: cuộn khung danh sách đang mở (cảm xúc / chia sẻ) hoặc bấm "Xem thêm bình luận",
// gom tên + link trang cá nhân, rồi cho người dùng bấm mở trang PCCV với danh sách đó.
// Không tự mở bài viết khác, không gửi dữ liệu đi đâu ngoài trang PCCV của CLB.
// Hàm này được chuyển thành chuỗi để làm bookmarklet nên KHÔNG được dùng biến bên ngoài.
window.fbHelper = function fbHelper(site, opts) {
  if (window.__pccvRunning) return;
  window.__pccvRunning = true;
  opts = opts || {};
  var _campaignId = opts.campaignId || '';
  try {
    var _scanM = location.hash.match(/#pccv-scan=(.+)/);
    if (_scanM) {
      var _scan = JSON.parse(decodeURIComponent(_scanM[1]));
      if (_scan.site) site = _scan.site;
      if (_scan.cid) _campaignId = _scan.cid;
      history.replaceState(null, '', location.pathname + location.search);
    }
  } catch(e) {}
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var JUNK = /^(thêm bạn bè|add friend|theo dõi|follow|đang theo dõi|following|nhắn tin|message|kết bạn|bạn bè|friends|xem thêm|see more|trả lời|reply|thích|like|chia sẻ|share|tất cả|all|bình luận|comment|xem bản dịch|see translation|\d.*)$/i;
  var box = document.createElement('div');
  box.style.cssText = 'position:fixed;z-index:2147483647;top:16px;right:16px;background:#1a56db;color:#fff;padding:12px 16px;' +
    'border-radius:10px;font:14px/1.45 system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.3);width:280px';
  box.innerHTML = '<b>📣 Gửi sang PCCV</b> <small style="opacity:.7">v7</small><div data-m style="margin:6px 0 10px">Đang bắt đầu…</div>' +
    '<button data-stop style="padding:6px 10px;border-radius:6px;border:0;cursor:pointer">Dừng & dùng danh sách hiện có</button>';
  document.body.appendChild(box);
  var stop = false;
  box.querySelector('[data-stop]').onclick = function () { stop = true; };
  var msg = function (t) { box.querySelector('[data-m]').textContent = t; };

  // Chế độ CẬP NHẬT HÀNG LOẠT: PCCV mở facebook.com kèm #pccv-batch=<danh sách> → đọc lần lượt từng trang cá nhân
  if (/#pccv-batch=/.test(location.hash)) {
    var list;
    try { list = JSON.parse(decodeURIComponent(escape(atob(location.hash.split('#pccv-batch=')[1])))); } catch (e) { list = null; }
    if (list && list.length) {
      var BAD = /^(facebook|log in|login|đăng nhập|log into facebook|trang không tồn tại|page not found|nội dung này hiện không hiển thị|this content isn't available.*)$/i;
      var cleanProfile = function (u) {
        try {
          var x = new URL(u);
          if (/profile\.php/.test(x.pathname)) return x.origin + '/profile.php?id=' + (x.searchParams.get('id') || '');
          var seg = x.pathname.split('/').filter(Boolean)[0] || '';
          return seg && seg !== 'share' && seg !== 'login' ? 'https://www.facebook.com/' + seg : '';
        } catch (e) { return ''; }
      };
      var JUNKH = /^(thông báo|notifications|bảng feed|feeds?|trang chủ|home|đoạn chat|chats?|tin nhắn|messages?|messenger|bạn bè|friends|menu|marketplace|video|watch|nhóm|groups|trang|pages|kỷ niệm|memories|đã lưu|saved|cài đặt|settings|tìm kiếm|search|facebook)$/i;
      var okName = function (t) { return !!t && t.length <= 70 && !BAD.test(t) && !JUNKH.test(t); };
      var cleanTitle = function (t) { return String(t || '').replace(/^\(\d+\+?\)\s*/, '').replace(/\s*[|\-–]\s*Facebook\s*$/i, '').trim(); };
      var pickName = function (d) {
        // 1) Tiêu đề tab: Facebook đặt thành "Tên | Facebook" khi trang cá nhân hiện xong
        var t = cleanTitle(d.title);
        if (okName(t)) return t;
        // 2) Thẻ h1 trong vùng nội dung chính
        var scope = d.querySelector('[role="main"]') || d;
        var hs = Array.prototype.map.call(scope.querySelectorAll('h1'), function (h) { return (h.innerText || h.textContent || '').trim().split('\n')[0].trim(); });
        return hs.filter(okName)[0] || '';
      };
      // Mở 1 cửa sổ nhỏ (ngay lúc bấm nút nên không bị chặn popup), rồi lần lượt chuyển cửa sổ đó tới từng trang cá nhân
      var win = window.open('about:blank', 'pccv-reader', 'width=1200,height=820,left=20,top=20');
      (async function () {
        var out = [];
        var prev = 'about:blank';
        for (var i = 0; i < list.length && !stop; i++) {
          var it = list[i];
          msg('Đang đọc ' + (i + 1) + '/' + list.length + '…');
          var name = '', url = '', why = '';
          if (win && !win.closed) {
            try {
              win.location.href = it.url;
              var t0 = Date.now();
              while (Date.now() - t0 < 20000 && !stop) {
                await sleep(800);
                var d = null;
                try { d = win.document; } catch (e) { why = 'không truy cập được cửa sổ'; break; }
                if (!d || !d.location || d.location.href === prev || d.location.href === 'about:blank') continue;
                if (/\/login|checkpoint/.test(d.location.pathname)) { why = 'Facebook yêu cầu đăng nhập/xác minh'; break; }
                url = cleanProfile(d.location.href) || url;
                var h = pickName(d);
                if (h) { name = h; prev = d.location.href; break; }
              }
              if (!name && !why) why = 'trang không hiện tên sau 20 giây (tiêu đề: "' + (function () { try { return win.document.title; } catch (e) { return '?'; } })() + '")';
              try { prev = win.location.href; } catch (e) { /* bỏ qua */ }
            } catch (e) { why = 'lỗi cửa sổ: ' + e.message; }
          } else { why = 'cửa sổ phụ bị chặn – hãy cho phép cửa sổ bật lên (popup) cho facebook.com'; }
          if (!name) {
            // Phương án dự phòng: tải HTML của trang
            try {
              var r = await fetch(it.url, { credentials: 'include' });
              var doc = new DOMParser().parseFromString(await r.text(), 'text/html');
              var og = doc.querySelector('meta[property="og:title"]');
              var nm = ((og && og.getAttribute('content')) || doc.title || '').replace(/^\(\d+\+?\)\s*/, '').replace(/\s*[|\-–]\s*Facebook\s*$/i, '').trim();
              if (okName(nm)) { name = nm; url = url || cleanProfile(r.url); why = ''; }
              else if (!why) why = 'tiêu đề trang: "' + (doc.title || '') + '"';
            } catch (e) { if (!why) why = 'không tải được trang'; }
          }
          out.push({ id: it.id, name: name, url: url, why: name ? '' : why });
          msg('Đang đọc ' + (i + 1) + '/' + list.length + '… ' + (name ? '✓ ' + name : '✗'));
          await sleep(1200 + Math.random() * 1200);
        }
        try { if (win && !win.closed) win.close(); } catch (e) { /* bỏ qua */ }
        var ok = out.filter(function (x) { return x.name; }).length;
        msg('Xong: đọc được ' + ok + '/' + out.length + ' người.');
        var b = box.querySelector('[data-stop]');
        var dd = btoa(unescape(encodeURIComponent(JSON.stringify({ kind: 'profiles', items: out, names: [] }))));
        b.textContent = '📨 Gửi kết quả về PCCV';
        b.onclick = function () { window.open(site + '#seed-import=' + dd, 'pccv-import'); box.remove(); window.__pccvRunning = false; };
      })();
      return;
    }
  }

  var visibleDialogs = function () { return Array.prototype.filter.call(document.querySelectorAll('[role="dialog"]'), function (d) { return d.getClientRects().length > 0; }); };
  var headOf = function (d) { return ((d.getAttribute('aria-label') || '') + ' ' + ((d.querySelector('h1,h2,[role="heading"]') || {}).textContent || '')).toLowerCase(); };
  var listKindOf = function (d) { var h = headOf(d); return /chia sẻ|share/.test(h) ? 'share' : /cảm xúc|react|lượt thích|likes?\b/.test(h) ? 'like' : ''; };
  var dialogs = visibleDialogs();
  var dlg = dialogs.length ? dialogs[dialogs.length - 1] : null;
  var listKind = dlg ? listKindOf(dlg) : '';
  // Bài viết: nếu Facebook mở bài viết dạng khung thì lấy khung đó, không thì vùng nội dung chính
  var postRoot = listKind ? null : (dlg || document.querySelector('[role="main"]') || document);

  // Chế độ TRANG CÁ NHÂN: không có khung danh sách, đường dẫn không phải bài viết → đọc tên + link thật
  var isPost = /\/(posts|permalink|photo|photos|videos|reel|watch|story\.php|groups|share|events)\b|story_fbid|fbid=|pfbid/.test(location.pathname + location.search);
  var hasPostSignals = !!document.querySelector('[role="article"][aria-label]') ||
    Array.prototype.some.call(document.querySelectorAll('[aria-label]'), function (n) { return /^(thích|yêu thích|like|love)\s*:\s*[\d.,]+|^(tất cả cảm xúc|all reactions)/i.test(n.getAttribute('aria-label') || ''); }) ||
    /\b\d+\s*(lượt chia sẻ|shares?)\b|tất cả cảm xúc|all reactions/i.test((document.querySelector('[role="main"]') || document.body).innerText || '');
  if (!dlg && !isPost && !hasPostSignals) {
    var JUNK1 = /^(facebook|thông báo|notifications|bảng feed|feeds?|trang chủ|home|đoạn chat|chats?|tin nhắn|messages?|messenger|bạn bè|friends|menu|marketplace|video|watch|nhóm|groups|trang|pages|tìm kiếm|search|đăng nhập|log in)$/i;
    var t1 = String(document.title || '').replace(/^\(\d+\+?\)\s*/, '').replace(/\s*[|\-–]\s*Facebook\s*$/i, '').trim();
    var main1 = document.querySelector('[role="main"]') || document;
    var h1 = (t1 && !JUNK1.test(t1) && t1.length <= 70) ? t1 : (Array.prototype.map.call(main1.querySelectorAll('h1'), function (h) { return (h.innerText || h.textContent || '').trim().split('\n')[0].trim(); })
      .filter(function (t) { return t && t.length <= 70 && !JUNK1.test(t); })[0] || '');
    var seg = location.pathname.split('/').filter(Boolean)[0] || '';
    var url = seg === 'profile.php' ? location.origin + '/profile.php?id=' + (new URLSearchParams(location.search).get('id') || '') : location.origin + '/' + seg;
    if (h1 && seg) {
      var pdata = btoa(unescape(encodeURIComponent(JSON.stringify({ kind: 'profile', name: h1, url: url, names: [] }))));
      box.querySelector('[data-m]').textContent = 'Trang cá nhân: ' + h1;
      var pb = box.querySelector('[data-stop]');
      pb.textContent = '📨 Lưu tên này vào PCCV';
      pb.onclick = function () { window.open(site + '#seed-import=' + pdata, 'pccv-import'); box.remove(); window.__pccvRunning = false; };
      var px = document.createElement('button');
      px.textContent = 'Đóng';
      px.style.cssText = 'margin-left:6px;padding:6px 10px;border-radius:6px;border:0;cursor:pointer';
      px.onclick = function () { box.remove(); window.__pccvRunning = false; };
      pb.after(px);
      return;
    }
  }

  var findScroller = function (el) {
    var candidates = [];
    var nodes = [el].concat(Array.prototype.slice.call(el.querySelectorAll('*')));
    nodes.forEach(function (n) {
      var s = getComputedStyle(n);
      if (/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 20) {
        candidates.push(n);
      }
    });
    if (!candidates.length) return null;
    // Ưu tiên scroller chứa nhiều a[href] (danh sách tên) nhất
    var best = null, bestLinks = -1;
    candidates.forEach(function (c) {
      var links = c.querySelectorAll('a[href]').length;
      if (links > bestLinks) { bestLinks = links; best = c; }
    });
    // Nếu không có a[href] nào, lấy scroller nhỏ nhất (innermost)
    if (bestLinks === 0) {
      best = candidates[0];
      candidates.forEach(function (c) {
        if (c.scrollHeight < best.scrollHeight) best = c;
      });
    }
    return best;
  };
  var cleanUrl = function (h) {
    try {
      var u = new URL(h, location.origin);
      if (/profile\.php/.test(u.pathname)) return u.origin + u.pathname + '?id=' + (u.searchParams.get('id') || '');
      return u.origin + u.pathname.replace(/\/$/, '');
    } catch (e) { return ''; }
  };
  var CMT = /^(?:bình luận (?:của|dưới tên)|phản hồi (?:của|dưới tên)|trả lời của|comment by|reply by)\s+(.+?)(?:\s+(?:vào|lúc|\d|cách đây|a |an ).*)?$/i;
  var textOf = function (a) { return (a.innerText || a.textContent || '').trim().split('\n')[0].trim(); };
  var goodLink = function (a) {
    var t = textOf(a);
    if (!t || t.length < 2 || t.length > 60 || JUNK.test(t)) return false;
    return !/\/(groups|pages|events|hashtag|photo|photos|watch|reel|stories|posts|videos)\b|comment_id=|\/ufi\//.test(a.getAttribute('href') || '');
  };
  // Người bình luận: chỉ lấy các khối bình luận (aria-label "Bình luận của …"), không lấy tác giả bài viết
  var collectComments = function (el) {
    var out = {};
    el.querySelectorAll('[role="article"][aria-label]').forEach(function (art) {
      var m = art.getAttribute('aria-label').match(CMT);
      if (!m) return;
      var name = m[1].trim();
      var link = Array.prototype.filter.call(art.querySelectorAll('a[href]'), goodLink).filter(function (a) { return textOf(a) === name; })[0] ||
        Array.prototype.filter.call(art.querySelectorAll('a[href]'), goodLink)[0];
      if (!out[name]) out[name] = link ? cleanUrl(link.getAttribute('href')) : '';
    });
    return out;
  };
  // Người trong khung danh sách (cảm xúc / chia sẻ)
  var collectList = function (el) {
    var out = {};
    // Tìm scroller bên trong (nếu có) để giới hạn phạm vi thu thập
    var scope = findScroller(el) || el;
    // 1) Cách chính: a[href] có tên hợp lệ — chỉ tìm trong phần cuộn
    scope.querySelectorAll('a[href]').forEach(function (a) {
      if (!goodLink(a)) return;
      var t = textOf(a);
      if (!(t in out) || !out[t]) out[t] = cleanUrl(a.getAttribute('href'));
    });
    // 2) Fallback: tìm a[href] trỏ đến trang cá nhân, lấy tên từ text bên trong link đó
    if (Object.keys(out).length === 0) {
      scope.querySelectorAll('a[href]').forEach(function (a) {
        var href = a.getAttribute('href') || '';
        // Chỉ lấy link profile (không phải link bài viết, group, page...)
        if (/\/(groups|pages|events|hashtag|photo|photos|watch|reel|stories|posts|videos|share)\b/.test(href)) return;
        if (!/^\/?[a-zA-Z0-9.]+\/?$/.test(href.replace(/^https?:\/\/[^/]+/, '').split('?')[0]) &&
            !/profile\.php/.test(href)) return;
        // Lấy tên = text đầu tiên trong link hoặc span con trực tiếp
        var t = textOf(a);
        if (t && t.length >= 2 && t.length <= 60 && !JUNK.test(t) && !/^\d/.test(t)) {
          if (!(t in out) || !out[t]) out[t] = cleanUrl(href);
        }
      });
    }
    return out;
  };
  var toArr = function (o) { return Object.keys(o).map(function (k) { return { name: k, url: o[k] }; }); };

  var scrollList = async function (d, label) {
    var stable = 0, last = -1, noScroller = 0, cachedSc = null;
    // Đợi nội dung dialog load (Facebook lazy-load danh sách cảm xúc)
    await sleep(2000);
    for (var i = 0; i < 400 && !stop; i++) {
      // Tìm scroller — khi đã tìm thấy, dùng lại nếu vẫn còn trong DOM
      var sc = (cachedSc && document.contains(cachedSc)) ? cachedSc : findScroller(d);
      if (sc) {
        cachedSc = sc;
        sc.scrollTop = sc.scrollHeight;
        noScroller = 0;
      } else {
        noScroller++;
        if (noScroller >= 8) break;
      }
      await sleep(1100 + Math.random() * 900);
      var n = Object.keys(collectList(d)).length;
      msg(label + ': đang tự cuộn… ' + n + ' tên' + (sc ? '' : ' (đợi scroller…)'));
      if (n === last) { if (++stable >= 4 && n > 0) break; } else { stable = 0; last = n; }
    }
    return collectList(d);
  };
  var MORE = /^(xem thêm bình luận|xem thêm \d+ bình luận|xem các bình luận trước|xem \d+ phản hồi|xem tất cả \d+ phản hồi|view more comments|view \d+ more comments|view previous comments|view \d+ repl(y|ies)|view all \d+ replies)/i;
  var expandComments = async function (el) {
    var stable = 0, last = -1;
    for (var i = 0; i < 300 && !stop; i++) {
      var btns = Array.prototype.filter.call(el.querySelectorAll('[role="button"]'), function (b) { return MORE.test((b.innerText || '').trim()); });
      btns.slice(0, 2).forEach(function (b) { b.click(); });
      var sc = el !== document && findScroller(el);
      if (sc) sc.scrollTop = sc.scrollHeight; else window.scrollBy(0, 500);
      await sleep(1100 + Math.random() * 900);
      var n = Object.keys(collectComments(el)).length;
      msg('Bình luận: đang mở thêm… ' + n + ' người');
      if (n === last && !btns.length) { if (++stable >= 3) break; } else { stable = 0; last = n; }
    }
    return collectComments(el);
  };
  var REACT = /^(thích|yêu thích|thương thương|haha|wow|buồn|phẫn nộ|like|love|care|sad|angry)\s*:\s*[\d.,]+/i;
  var clickableOf = function (n) { return n.closest('[role="button"],[role="link"],[tabindex]') || n; };
  // Trả về danh sách chỗ có thể bấm, theo thứ tự ưu tiên
  var findTriggers = function (el, k) {
    var nodes = Array.prototype.slice.call(el.querySelectorAll('[aria-label],[role="button"],span,div'));
    var seen = [], out = [];
    var add = function (n) { if (!n) return; var c = clickableOf(n); if (seen.indexOf(c) < 0 && !c.closest('[role="article"][aria-label]')) { seen.push(c); out.push(c); } };
    if (k === 'like') {
      nodes.forEach(function (n) { if (/^(tất cả cảm xúc|all reactions|xem ai đã bày tỏ cảm xúc|see who reacted|cảm xúc\s*:|reactions\s*:)/i.test((n.getAttribute('aria-label') || '').trim())) add(n); });
      nodes.forEach(function (n) {
        if (n.children.length === 0 && /^(tất cả cảm xúc|all reactions)\s*:?$/i.test(textOf(n))) {
          // chữ ẩn "Tất cả cảm xúc:" – chỗ bấm thật là khối chứa con số tổng bên cạnh
          var box = n.parentElement;
          for (var up = 0; up < 4 && box; up++, box = box.parentElement) {
            var btn = box.querySelector('[role="button"]');
            if (btn && /\d/.test(btn.innerText || '')) { add(btn); break; }
          }
          add(n);
        }
      });
      nodes.forEach(function (n) { if (REACT.test((n.getAttribute('aria-label') || '').trim())) add(n); });
    } else {
      nodes.forEach(function (n) { if (/^[\d.,]+\s*(k|n|tr|m)?\s*(lượt chia sẻ|chia sẻ|shares?)$/i.test(textOf(n))) add(n); });
    }
    return out;
  };
  var openList = async function (triggers, k) {
    for (var i = 0; i < triggers.length && i < 4; i++) {
      var before = visibleDialogs();
      // Cuộn trigger vào tầm nhìn trước khi click
      triggers[i].scrollIntoView({ block: 'center', behavior: 'instant' });
      await sleep(300);
      triggers[i].click();
      // Đợi lâu hơn (25 lần × 500ms = 12.5s) vì Facebook load dialog chậm
      for (var t = 0; t < 25; t++) {
        await sleep(500);
        var now = visibleDialogs().filter(function (d) { return before.indexOf(d) < 0; });
        var hit = now.filter(function (d) { return listKindOf(d) === k; })[0] || now[0];
        if (hit) {
          // Đợi thêm cho nội dung dialog load xong
          await sleep(2000);
          if (k === 'like') {
            // Nếu khung đang lọc 1 loại cảm xúc → chuyển sang tab "Tất cả"
            var all = Array.prototype.filter.call(hit.querySelectorAll('[role="tab"]'), function (tb) { return /^(tất cả|all)(\s|$|\d)/i.test(textOf(tb)); })[0];
            if (all && all.getAttribute('aria-selected') !== 'true') { all.click(); await sleep(2000); }
          }
          return hit;
        }
      }
    }
    return null;
  };
  var debugLabels = function (el) {
    return Array.prototype.map.call(el.querySelectorAll('[aria-label]'), function (n) { return (n.getAttribute('aria-label') || '').trim(); })
      .filter(function (t) { return /\d/.test(t) && t.length < 60; }).slice(0, 8).join(' | ');
  };
  var closeDialog = async function (d) {
    var b = d.querySelector('[aria-label="Đóng"],[aria-label="Close"]');
    if (b) b.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
    for (var t = 0; t < 10 && document.contains(d) && d.getClientRects().length; t++) await sleep(300);
  };
  var finish = function (payload, summary) {
    if (_campaignId) payload.campaignId = _campaignId;
    var data = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
    if (opts.onDone) {
      msg(summary + ' – đang gửi về PCCV…');
      try { opts.onDone(data); } catch(e) {}
      setTimeout(function() { box.remove(); window.__pccvRunning = false; }, 2000);
      return;
    }
    msg(summary);
    var btn = box.querySelector('[data-stop]');
    btn.textContent = '📨 Mở PCCV để đối chiếu';
    btn.onclick = function () { window.open(site + '#seed-import=' + data, 'pccv-import'); box.remove(); window.__pccvRunning = false; };
    var x = document.createElement('button');
    x.textContent = 'Đóng';
    x.style.cssText = 'margin-left:6px;padding:6px 10px;border-radius:6px;border:0;cursor:pointer';
    x.onclick = function () { box.remove(); window.__pccvRunning = false; };
    btn.after(x);
  };
  var post = location.href.split('#')[0];
  var LBL = { like: 'Cảm xúc', comment: 'Bình luận', share: 'Chia sẻ' };

  (async function () {
    if (listKind) {
      // Đang mở sẵn 1 khung cảm xúc / chia sẻ → chỉ lấy khung đó
      var one = toArr(await scrollList(dlg, LBL[listKind]));
      finish({ kind: listKind, post: post, names: one }, 'Xong! ' + LBL[listKind] + ': ' + one.length + ' tên.');
      return;
    }
    // Chế độ ĐẦY ĐỦ: bình luận + cảm xúc + chia sẻ của bài viết đang mở
    var lists = {}, missing = {};
    lists.comment = toArr(await expandComments(postRoot));
    // Cuộn về đầu bài viết trước khi quét cảm xúc (expandComments đã cuộn xuống dưới)
    // Cuộn đến chính postRoot thay vì đầu trang (tránh nhầm bài viết khác phía trên)
    if (postRoot && postRoot.scrollIntoView) {
      postRoot.scrollIntoView({ block: 'start', behavior: 'instant' });
    } else {
      window.scrollTo(0, 0);
    }
    await sleep(1500);
    // Tìm đúng bài viết chính để quét cảm xúc
    // Ưu tiên: postRoot gốc (nếu là dialog thì chính xác nhất)
    // Nếu postRoot là [role="main"], tìm article đầu tiên của bài viết (không phải bình luận)
    var reactRoot = postRoot;
    if (postRoot === document || (postRoot && !postRoot.closest('[role="dialog"]'))) {
      // Tìm article chính của bài viết (không phải comment)
      var articles = Array.prototype.filter.call(
        (postRoot || document).querySelectorAll('[role="article"]'),
        function (art) {
          var label = (art.getAttribute('aria-label') || '').toLowerCase();
          // Bỏ qua các article là bình luận
          return !/^(bình luận|phản hồi|trả lời|comment|reply)\s/i.test(label);
        }
      );
      // Lấy article đầu tiên (bài viết chính)
      if (articles.length) {
        // Article có thể lồng nhau — lấy cái ngoài cùng (chứa cả nội dung + thanh cảm xúc)
        reactRoot = articles[0];
        // Nhưng nút cảm xúc thường nằm NGOÀI article, trong parent container
        // → mở rộng lên 1-2 cấp cha để bao gồm thanh reaction
        var parent = reactRoot.parentElement;
        if (parent) reactRoot = parent;
      }
    }
    for (var k of ['like']) { // share: thành viên tự nộp link, không quét
      if (stop) break;
      msg(LBL[k] + ': đang mở danh sách…');
      var trigs = findTriggers(reactRoot, k);
      if (!trigs.length) { missing[k] = 'không thấy nút ' + (k === 'like' ? 'số lượt cảm xúc' : 'số lượt chia sẻ') + ' (có thể bài chưa có ' + LBL[k].toLowerCase() + '). Nhãn thấy được: ' + debugLabels(postRoot); continue; }
      var d = await openList(trigs, k);
      if (!d) { missing[k] = 'đã thử bấm ' + trigs.length + ' chỗ nhưng không mở được khung danh sách. Nhãn thấy được: ' + debugLabels(postRoot); continue; }
      lists[k] = toArr(await scrollList(d, LBL[k]));
      await closeDialog(d);
      await sleep(800);
    }
    var sum = ['like', 'comment'].map(function (k) { return LBL[k] + ': ' + (lists[k] ? lists[k].length : '✗'); }).join(' · ');
    finish({ kind: 'all', post: post, lists: lists, missing: missing, names: [] }, 'Xong! ' + sum);
  })();
};
